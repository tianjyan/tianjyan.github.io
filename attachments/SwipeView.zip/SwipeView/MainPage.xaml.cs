﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Navigation;

//“空白页”项模板在 http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 上有介绍

namespace SwipeView
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            //如果是其他的带有滚动的控件，要禁用滚动，手机版才能使用。PC版无影响
            ScrollViewer.SetVerticalScrollMode(listbox, ScrollMode.Disabled);
        }

        private new void ManipulationCompleted(object sender, ManipulationCompletedRoutedEventArgs e)
        {
            var x = e.Velocities.Linear.X;
            if (x <= -0.1)
            {
                OpenPanel();
            }
            else if (x > -0.1 && x < 0.1)
            {
                if (Math.Abs((Panel.RenderTransform as CompositeTransform).TranslateX) > 150)
                {
                    OpenPanel();
                }
                else
                {
                    ClosePanel();
                }

            }
            else
            {
                ClosePanel();
            }
        }

        private new void ManipulationDelta(object sender, ManipulationDeltaRoutedEventArgs e)
        {
            var x = (Panel.RenderTransform as CompositeTransform).TranslateX + e.Delta.Translation.X;
            if (x < -300)
            {
                x = -300;
            }
            (Panel.RenderTransform as CompositeTransform).TranslateX = x;
            (ManipulationLayout.RenderTransform as CompositeTransform).TranslateX = x;
        }

        private void DismissLayout_Tapped(object sender, TappedRoutedEventArgs e)
        {
            ClosePanel();
        }

        private void OpenPanel()
        {
            OpenView.Begin();
            DismissLayout.Visibility = Visibility.Visible;
        }

        private void ClosePanel()
        {
            CloseView.Begin();
            DismissLayout.Visibility = Visibility.Collapsed;
        }
    }
}
