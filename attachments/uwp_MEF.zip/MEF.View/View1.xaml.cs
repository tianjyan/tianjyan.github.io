﻿using MEF.Abstract;
using System.Composition;
using Windows.UI.Xaml.Controls;

namespace MEF.View
{
    [Export(Constant.Confing.View1,typeof(IView))]
    public sealed partial class View1 : UserControl, IView
    {
        IService Service;
        IViewModel ViewModel;
        [ImportingConstructor]
        public View1(
            [Import(Constant.Confing.SampleService)]IService service, 
            [Import(Constant.Confing.ViewModel1)]IViewModel viewModel)
        {
            this.InitializeComponent();
            this.Service = service;
            this.ViewModel = viewModel;
        }

        private void Button_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            Service.QueryData(ViewModel.Number, ShowValue);
        }

        private void ShowValue(int i)
        {
            Btn.Content = i;
        }
    }
}
