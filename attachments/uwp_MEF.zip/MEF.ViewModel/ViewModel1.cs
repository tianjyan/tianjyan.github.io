﻿using MEF.Abstract;
using System.Composition;

namespace MEF.ViewModel
{
    [Export(Constant.Confing.ViewModel1,typeof(IViewModel))]
    public class ViewModel1 : IViewModel
    {
        private int number = 2;

        public int Number
        {
            get
            {
                return number;
            }

            set
            {
                number = value;
            }
        }
    }
}
