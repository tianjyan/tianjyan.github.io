﻿using MEF.Abstract;
using System.Composition;

namespace MEF.ViewModel
{
    [Export(Constant.Confing.ViewModel2, typeof(IViewModel))]
    public class ViewModel2 : IViewModel
    {
        private int number = 4;

        public int Number
        {
            get
            {
                return number;
            }

            set
            {
                number = value;
            }
        }
    }
}
