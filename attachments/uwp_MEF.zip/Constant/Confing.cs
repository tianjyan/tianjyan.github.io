﻿namespace Constant
{
    public static class Confing
    {
        public const string SampleService = nameof(SampleService);
        public const string View1 = nameof(View1);
        public const string View2 = nameof(View2);
        public const string ViewModel1 = nameof(ViewModel1);
        public const string ViewModel2 = nameof(ViewModel2);
    }
}
