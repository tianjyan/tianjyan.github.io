﻿using MEF.Abstract;
using System;
using System.Composition;

namespace MEF.Service
{
    [Export(Constant.Confing.SampleService,typeof(IService))]
    public class SampleService : IService
    {
        public void QueryData(int numuber, Action<int> action)
        {
            action(numuber);
        }
    }
}
