﻿using MEF.Abstract;
using System.Collections.Generic;
using System.Composition;
using System.Composition.Hosting;
using System.Reflection;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace uwp_MEF
{

    public sealed partial class MainPage : Page
    {
        [Import(Constant.Confing.View1)]
        public IView View1 { get; set; }

        [Import(Constant.Confing.View2)]
        public IView View2 { get; set; }

        public MainPage()
        {
            this.InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        private CompositionHost host;

        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            List<Assembly> assemblies = new List<Assembly>()
            {
                Assembly.Load(new AssemblyName("MEF.Service")),
                Assembly.Load(new AssemblyName("MEF.View")),
                Assembly.Load(new AssemblyName("MEF.ViewModel")),
                Assembly.Load(new AssemblyName("MEF.Abstract"))
                };
            ContainerConfiguration configuration = new ContainerConfiguration().WithAssemblies(assemblies);
            host = configuration.CreateContainer();
            host.SatisfyImports(this);
        }

        private void View1_Click(object sender, RoutedEventArgs e)
        {
            IView view = host.GetExport(typeof(IView), Constant.Confing.View1) as IView;
            frame.Content = view;
        }

        private void View2_Click(object sender, RoutedEventArgs e)
        {
            IView view = host.GetExport(typeof(IView), Constant.Confing.View2) as IView;
            frame.Content = view;
        }
    }
}
