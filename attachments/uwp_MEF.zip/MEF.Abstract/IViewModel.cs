﻿namespace MEF.Abstract
{
    public interface IViewModel
    {
        int Number { get; set; }
    }
}
