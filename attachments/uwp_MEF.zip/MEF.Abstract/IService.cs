﻿using System;

namespace MEF.Abstract
{
    public interface IService
    {
        void QueryData(int numuber, Action<int> action);
    }
}
