﻿namespace MEF.Abstract
{
    public interface IView
    {
    }
}
