﻿using PrismSample.Infrastructure.Abstract.Presentation.Interface;
using Microsoft.Practices.Prism.Mvvm;
using System.ComponentModel.Composition;
using PrismSample.Infrastructure.Abstract.Presentation.AbstractClass;

namespace PrismSample
{
    [Export("ShellViewModel",typeof(IViewModel))]
    public class ShellViewModel : ViewModelBase
    {
        private string _text;

        public string Text
        {
            get { return _text; }
            set { SetProperty(ref _text, value); }
        }

        [ImportingConstructor]
        public ShellViewModel([Import("ShellView", typeof(IView))]  IView view)
        {
            this.View = view;
            this._text = "Hello World";
            this.View.DataContext = this;
        }
    }
}
