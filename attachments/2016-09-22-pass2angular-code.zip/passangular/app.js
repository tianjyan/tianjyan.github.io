var express = require('express'),
    path = require('path'),
    jsonfile = require('jsonfile'),
    mockdata;

var app = express();

app.use(express.static(path.join(__dirname, 'public')));
app.set('views', './views');
app.set('view engine', 'ejs');

jsonfile.readFile('./mock.json', function(err, data) {
    mockdata = data;
    console.log("mock data: ");
    console.log(data);
});

app.get('/sample1', function(req, res){
    res.render('sample1', {
        "title": mockdata.sample1,
        "users": mockdata.users
    });
});

app.get('/sample2', function(req, res){
    res.render('sample2', {
        "title": mockdata.sample2
    });
});

app.get('/sample2/users', function(req, res){
    res.json(mockdata.users);
});

app.get('/sample3', function(req, res){
    res.render('sample1', {
        "title": mockdata.sample3,
        "users": mockdata.users
    });
});

app.listen(4000, function() {
    console.log("app listening on port 4000!");
});