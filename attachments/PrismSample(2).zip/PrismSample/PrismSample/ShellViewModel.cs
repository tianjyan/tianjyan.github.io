﻿using PrismSample.Infrastructure.Abstract.Presentation.Interface;
using Microsoft.Practices.Prism.Mvvm;
using System.ComponentModel.Composition;
using PrismSample.Infrastructure.Abstract.Presentation.AbstractClass;
using Prism.Logging;

namespace PrismSample
{
    [Export("ShellViewModel",typeof(IViewModel))]
    public class ShellViewModel : ViewModelBase
    {
        private string _text;

        public string Text
        {
            get { return _text; }
            set { SetProperty(ref _text, value); }
        }

        [ImportingConstructor]
        public ShellViewModel([Import("ShellView", typeof(IView))]IView view, [Import]ILoggerFacade logger)
        {
            this.View = view;
            this._text = "Hello World";
            this.View.DataContext = this;


            logger.Log("ShellViewModel Created", Category.Info, Priority.None);
        }
    }
}
