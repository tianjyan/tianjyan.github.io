﻿using Prism.Mef;
using PrismSample.Infrastructure.Abstract.Presentation.Interface;
using System.ComponentModel.Composition.Hosting;
using System.Windows;
using Prism.Logging;
using PrismSample.Infrastructure.Logger;
using System.IO;
using System;

namespace PrismSample
{
    public class Bootstrapper : MefBootstrapper
    {
        private const string SEARCH_PATTERN = "PrismSample.Infrastructure.*.dll";

        protected override DependencyObject CreateShell()
        {
            IViewModel shellViewModel = this.Container.GetExportedValue<IViewModel>("ShellViewModel");      
            return shellViewModel.View as DependencyObject;
        }

        protected override void InitializeShell()
        {
            Application.Current.MainWindow = (Shell)this.Shell;
            Application.Current.MainWindow.Show();
        }

        protected override void ConfigureAggregateCatalog()
        {
            base.ConfigureAggregateCatalog();

            //加载自己
            this.AggregateCatalog.Catalogs.Add(new AssemblyCatalog(this.GetType().Assembly));

            //加载当前目录
            DirectoryInfo dirInfo = new DirectoryInfo(@".\");
            foreach (FileInfo fileInfo in dirInfo.EnumerateFiles(SEARCH_PATTERN))
            {
                try
                {
                    this.AggregateCatalog.Catalogs.Add(new AssemblyCatalog(fileInfo.FullName));
                }
                catch (Exception ex)
                {
                    this.Logger.Log( string.Format("导入异常：{0}", ex.Message), Category.Exception, Priority.None);
                }
            }
        }

        protected override ILoggerFacade CreateLogger()
        {
            return new Logger();
        }
    }
}
