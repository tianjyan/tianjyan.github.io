﻿using Microsoft.Practices.Prism.Mvvm;

namespace PrismSample.Infrastructure.Abstract.Presentation.Interface
{
    public interface IViewModel
    {
        IView View { get; }
    }
}
