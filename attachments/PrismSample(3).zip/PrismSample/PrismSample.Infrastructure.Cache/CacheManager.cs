﻿using Microsoft.Practices.EnterpriseLibrary.Caching;
using System.ComponentModel.Composition;

namespace PrismSample.Infrastructure.Cache
{
    [Export("PrismSampleCache", typeof(ICacheManager))]
    public class CacheManager : ICacheManager
    {
        ICacheManager _cacheManager;

        public CacheManager()
        {
            _cacheManager = CacheFactory.GetCacheManager("MemoryCacheManager");
        }

        public object this[string key]
        {
            get
            {
                return _cacheManager[key];
            }
        }

        public int Count
        {
            get
            {
                return _cacheManager.Count;
            }
        }

        public void Add(string key, object value)
        {
            _cacheManager.Add(key, value);
        }

        public void Add(string key, object value, CacheItemPriority scavengingPriority, ICacheItemRefreshAction refreshAction, params ICacheItemExpiration[] expirations)
        {
            _cacheManager.Add(key, value, scavengingPriority, refreshAction, expirations);
        }

        public bool Contains(string key)
        {
            return _cacheManager.Contains(key);
        }

        public void Flush()
        {
            _cacheManager.Flush();
        }

        public object GetData(string key)
        {
           return  _cacheManager.GetData(key);
        }

        public void Remove(string key)
        {
            _cacheManager.Remove(key);
        }
    }
}
