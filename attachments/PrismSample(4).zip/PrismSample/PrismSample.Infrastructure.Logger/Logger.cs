﻿using log4net;
using log4net.Config;
using Prism.Logging;
using PrismSample.Infrastructure.Common.Constant;
using System;
using System.IO;

namespace PrismSample.Infrastructure.Logger
{
    public class Logger : ILoggerFacade
    {
        private ILog _debugLogger;
        private ILog _errorLogger;
        private ILog _infoLogger;
        private ILog _warnLogger;

        public Logger()
        {
            var logCfg = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + "logging.config");
            XmlConfigurator.ConfigureAndWatch(logCfg);

            _debugLogger = LogManager.GetLogger(Config.LogDebug);
            _errorLogger = LogManager.GetLogger(Config.LogError);
            _infoLogger = LogManager.GetLogger(Config.LogInfo);
            _warnLogger = LogManager.GetLogger(Config.LogWarn);
        }

        public void Log(string message, Category category, Priority priority)
        {
            switch(category)
            {
                case Category.Debug:
                    _debugLogger.Debug(message ?? "");
                    break;
                case Category.Exception:
                    _errorLogger.Error(message ?? "");
                    break;
                case Category.Info:
                    _infoLogger.Info(message ?? "");
                    break;
                case Category.Warn:
                    _warnLogger.Warn(message ?? "");
                    break;
            }
        }
    }
}
