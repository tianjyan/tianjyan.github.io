﻿using PrismSample.Infrastructure.Abstract.Presentation.Interface;
using Microsoft.Practices.Prism.Mvvm;
using System.ComponentModel.Composition;
using PrismSample.Infrastructure.Abstract.Presentation.AbstractClass;
using Prism.Logging;
using Microsoft.Practices.EnterpriseLibrary.Caching;
using PrismSample.Infrastructure.Common.Constant;

namespace PrismSample
{
    [Export(ExportViewModel.ShellViewModel, typeof(IViewModel))]
    public class ShellViewModel : ViewModelBase
    {
        private string _text;

        public string Text
        {
            get { return _text; }
            set { SetProperty(ref _text, value); }
        }

        [ImportingConstructor]
        public ShellViewModel([Import(ExportView.ShellView, typeof(IView))]IView view, 
                              [Import]ILoggerFacade logger, 
                              [Import(Config.CacheManager, typeof(ICacheManager))] ICacheManager _cacheManager)
        {
            this.View = view;
            this.View.DataContext = this;

            _cacheManager.Add("SampleValue", "CacheValue");
            this._text = _cacheManager.GetData("SampleValue").ToString();
            logger.Log("ShellViewModel Created", Category.Info, Priority.None);
        }

    }
}
