﻿using Microsoft.Practices.Prism.Mvvm;
using PrismSample.Infrastructure.Common.Constant;
using PrismSample.Infrastructure.Common.Event;
using PrismSample.Infrastructure.Common.Until;
using System.ComponentModel.Composition;
using System.Windows;

namespace PrismSample
{
    [Export(ExportView.ShellView, typeof(IView))]
    public partial class Shell : Window, IView
    {
        public Shell()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OnNewWindowEventArgs arg = new OnNewWindowEventArgs(ExportViewModel.SecondViewModel, "Hi, Second View", AfterOpenSecondView);
            Messager.Default.EventAggregator.GetEvent<OnNewWindowEvent>().Publish(arg);
        }

        private void AfterOpenSecondView()
        {
            Info.Text = "SecondView Opened";
        }
    }
}
