﻿using Prism.Mef;
using System.ComponentModel.Composition.Hosting;
using System.Windows;
using Prism.Logging;
using PrismSample.Infrastructure.Logger;
using System.IO;
using System;
using PrismSample.Infrastructure.Common.Constant;
using PrismSample.Infrastructure.Common.Until;
using PrismSample.Infrastructure.Common.Event;
using PrismSample.Infrastructure.Abstract.Presentation.Interface;

namespace PrismSample
{
    public class Bootstrapper : MefBootstrapper
    {
        private const string SEARCH_PATTERN = "PrismSample.*.dll";

        public Bootstrapper() : base()
        {
            Messager.Default.EventAggregator.GetEvent<OnNewWindowEvent>().Subscribe(OnNewWindow);
        }

        protected override DependencyObject CreateShell()
        {
            IViewModel shellViewModel = this.Container.GetExportedValue<IViewModel>(ExportViewModel.ShellViewModel);      
            return shellViewModel.View as DependencyObject;
        }

        protected override void InitializeShell()
        {
            Application.Current.MainWindow = (Shell)this.Shell;
            Application.Current.MainWindow.Show();
        }

        protected override void ConfigureAggregateCatalog()
        {
            base.ConfigureAggregateCatalog();

            //加载自己
            this.AggregateCatalog.Catalogs.Add(new AssemblyCatalog(this.GetType().Assembly));

            //加载当前目录
            DirectoryInfo dirInfo = new DirectoryInfo(@".\");
            foreach (FileInfo fileInfo in dirInfo.EnumerateFiles(SEARCH_PATTERN))
            {
                try
                {
                    this.AggregateCatalog.Catalogs.Add(new AssemblyCatalog(fileInfo.FullName));
                }
                catch (Exception ex)
                {
                    this.Logger.Log( string.Format("导入异常：{0}", ex.Message), Category.Exception, Priority.None);
                }
            }
        }

        protected override ILoggerFacade CreateLogger()
        {
            return new Logger();
        }

        private void OnNewWindow(OnNewWindowEventArgs args)
        {
            IViewModel viewModel = this.Container.GetExportedValue<IViewModel>(args.ViewModelName);
            Window window = new Window();
            window.Content = viewModel.View;
            viewModel.InitializeContext(args.Parameter);
            window.Show();
            args.AfterShowAction?.Invoke();
        }
    }
}
