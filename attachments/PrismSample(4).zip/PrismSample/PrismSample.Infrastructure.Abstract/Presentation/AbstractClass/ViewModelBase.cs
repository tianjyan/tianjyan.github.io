﻿using Microsoft.Practices.Prism.Mvvm;
using PrismSample.Infrastructure.Abstract.Presentation.Interface;

namespace PrismSample.Infrastructure.Abstract.Presentation.AbstractClass
{
    public abstract class ViewModelBase : BindableBase, IViewModel
    {
        public IView View { get; protected set; }
        public virtual void InitializeContext(object arg)
        {

        }
    }
}
