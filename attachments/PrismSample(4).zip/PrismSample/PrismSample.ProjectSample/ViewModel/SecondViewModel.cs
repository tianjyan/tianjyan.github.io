﻿using Microsoft.Practices.Prism.Mvvm;
using Prism.Logging;
using PrismSample.Infrastructure.Abstract.Presentation.AbstractClass;
using PrismSample.Infrastructure.Abstract.Presentation.Interface;
using PrismSample.Infrastructure.Common.Constant;
using System.ComponentModel.Composition;

namespace PrismSample.ProjectSample.ViewModel
{
    [Export(ExportViewModel.SecondViewModel,typeof(IViewModel))]
    public class SecondViewModel : ViewModelBase
    {
        [Import]
        ILoggerFacade _logger;

        [ImportingConstructor]
        public SecondViewModel([Import(ExportView.SecondView, typeof(IView))]IView view)
        {
            this.View = view;
            this.View.DataContext = this;
        }

        public override void InitializeContext(object arg)
        {
            base.InitializeContext(arg);
            _logger.Log("SecondViewModel Initialized", Category.Info, Priority.None);
        }
    }
}
