﻿using Microsoft.Practices.Prism.Mvvm;
using PrismSample.Infrastructure.Common.Constant;
using System.ComponentModel.Composition;
using System.Windows.Controls;

namespace PrismSample.ProjectSample.View
{
    [Export(ExportView.SecondView, typeof(IView))]
    public partial class SecondView : UserControl , IView
    {
        public SecondView()
        {
            InitializeComponent();
        }
    }
}
