﻿using Microsoft.Practices.EnterpriseLibrary.Caching;
using PrismSample.Infrastructure.Common.Constant;
using System.ComponentModel.Composition;

namespace PrismSample.Infrastructure.Cache
{
    [Export(Config.CacheManager, typeof(ICacheManager))]
    public class CacheManager : ICacheManager
    {
        #region Field
        ICacheManager _cacheManager;
        #endregion

        #region Constructor
        public CacheManager()
        {
            _cacheManager = CacheFactory.GetCacheManager(Config.DefaultCache);
        }
        #endregion

        #region Property
        public object this[string key]
        {
            get
            {
                return _cacheManager[key];
            }
        }

        public int Count
        {
            get
            {
                return _cacheManager.Count;
            }
        }
        #endregion

        #region Fucntions
        public void Add(string key, object value)
        {
            _cacheManager.Add(key, value);
        }

        public void Add(string key, object value, CacheItemPriority scavengingPriority, ICacheItemRefreshAction refreshAction, params ICacheItemExpiration[] expirations)
        {
            _cacheManager.Add(key, value, scavengingPriority, refreshAction, expirations);
        }

        public bool Contains(string key)
        {
            return _cacheManager.Contains(key);
        }

        public void Flush()
        {
            _cacheManager.Flush();
        }

        public object GetData(string key)
        {
           return  _cacheManager.GetData(key);
        }

        public void Remove(string key)
        {
            _cacheManager.Remove(key);
        }
        #endregion
    }
}
