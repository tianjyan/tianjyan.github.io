﻿namespace PrismSample.Infrastructure.Common.Constant
{
    public static class ExportView
    {
        public const string ShellView = nameof(ShellView);
        public const string SecondView = nameof(SecondView);
    }
}
