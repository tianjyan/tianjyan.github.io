﻿namespace PrismSample.Infrastructure.Common.Constant
{
    public static class ExportViewModel
    {
        public const string ShellViewModel = nameof(ShellViewModel);
        public const string SecondViewModel = nameof(SecondViewModel);
    }
}
