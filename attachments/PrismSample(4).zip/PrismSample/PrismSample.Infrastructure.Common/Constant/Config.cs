﻿namespace PrismSample.Infrastructure.Common.Constant
{
    public static class Config
    {
        public const string DefaultCache = "MemoryCacheManager";
        public const string CacheManager = "PrismSampleCache";
        public const string LogDebug = "logdebug";
        public const string LogError = "logerror";
        public const string LogInfo = "loginfo";
        public const string LogWarn = "logwarn";
    }
}
