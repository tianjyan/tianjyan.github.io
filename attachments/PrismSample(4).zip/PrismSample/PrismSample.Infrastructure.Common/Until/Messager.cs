﻿using Microsoft.Practices.Prism.PubSubEvents;

namespace PrismSample.Infrastructure.Common.Until
{
    public class Messager
    {
        public IEventAggregator EventAggregator { get; private set; }
        private Messager()
        {
            EventAggregator = new EventAggregator();
        }

        public static readonly Messager Default = new Messager();
    }
}
