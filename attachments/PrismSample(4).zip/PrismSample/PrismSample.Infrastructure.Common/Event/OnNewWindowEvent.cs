﻿using Microsoft.Practices.Prism.PubSubEvents;

namespace PrismSample.Infrastructure.Common.Event
{
    public class OnNewWindowEvent : PubSubEvent<OnNewWindowEventArgs>
    {
        
    }
}
