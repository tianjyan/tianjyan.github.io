﻿using System;

namespace PrismSample.Infrastructure.Common.Event
{
    public class OnNewWindowEventArgs : EventArgs
    {
        public string ViewModelName { get; private set; }
        public object Parameter { get; private set; }
        public Action AfterShowAction { get; private set; }

        public OnNewWindowEventArgs(string viewModelName, object parameter)
        {
            ViewModelName = viewModelName;
            Parameter = parameter;
        }

        public OnNewWindowEventArgs(string viewModelName, object parameter, Action afterShowAction) : 
            this(viewModelName, parameter)
        {
            AfterShowAction = afterShowAction;
        }
    }
}
